import java.util.Random;
import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
 
/**
 * Write a description of class Letters here.
 * 
 * @author (Blythe) 
 * @version (March 26, 2019)
 */
public class Letters extends Actor
{
    private int time;
    private int xShowed;
    private int score;
    private char c;
    private int readyTime;
    private int readyCounter;

    Letters() {
        readyTime = 1;
        readyCounter = readyTime;
        xShowed = 0;
        score = 0;
        time = 0;
    }
    
    /**
     * Act - do whatever the Letters wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        if (readyCounter == readyTime) {
             Random rnd = new Random();
             c = (char) (rnd.nextInt(17) + 'i');
             World w = getWorld();
             w.showText("" + c, w.getWidth()/2, w.getHeight()/2);
             readyCounter = 0;
        } else {
            readyCounter++;
        }
        checkX(c);
    }
    
    public void checkX(char c) {
        if (c == 'x') {
            time++;
            if (time < 2) {
                xShowed++;
            } else if (time > 2) {
                time = 0;
            }
        }
        if (c == 'x' && Greenfoot.getKey() == "space") {
            if (time < 2) {
                score++;
            }
        }
        System.out.println("X Showed: " + xShowed);
        System.out.println("Score: " + score);
   }
}

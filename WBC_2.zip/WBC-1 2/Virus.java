import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Virus here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Virus extends Actor
{
    /**
     * Move the virsus to the left 4, and turn counter-cockwise 1
     */
    public void act() 
    {
        setLocation(getX()-4, getY());
        turn(-1);
    }    
}

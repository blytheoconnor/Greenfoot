import greenfoot.*;

/**
 * A rocket that can be controlled by the arrowkeys: up, left, right.
 * The gun is fired by hitting the 'space' key. 'z' releases a proton wave.
 * 
 * @author Poul Henriksen
 * @author Michael Kölling
 * 
 * @version 1.1
 */
public class Rocket extends SmoothMover
{
    private static final int gunReloadTime = 5;         // The minimum delay between firing the gun.
    private int reloadDelayCount;               // How long ago we fired the gun the last time.
    
    private static final int pwReloadTime = 2000;         // The minimum delay between dropping a Proton Wave.
    private int pwReloadDelayCount;               // How long ago we dropped a Proton Wave the last time.

    private static final int sReloadTime = 300;         // The minimum delay releasing a Shield.
    private int sReloadDelayCount;               // How long ago we released a Shield the last time.

    private GreenfootImage rocket = new GreenfootImage("rocket.png");    
    private GreenfootImage rocketWithThrust = new GreenfootImage("rocketWithThrust.png");

    /**
     * Initialise this rocket.
     */
    public Rocket()
    {
        reloadDelayCount = 5;
        pwReloadDelayCount = pwReloadTime;
        sReloadDelayCount = sReloadTime;
        addToVelocity(new Vector(Greenfoot.getRandomNumber(360), 0.75));
    }

    /**
     * Do what a rocket's gotta do. (Which is: mostly flying about, and turning,
     * accelerating and shooting when the right keys are pressed.)
     */
    public void act()
    {
        readyDisplay();
        checkKeys();
        reloadDelayCount++;
        pwReloadDelayCount++;
        sReloadDelayCount++;
        move();
    }
    
    /**
     * Check whether there are any key pressed and react to them.
     */
    private void checkKeys() 
    {
        if (Greenfoot.isKeyDown("space")) 
        {
            fire();
        }
        if (Greenfoot.isKeyDown("z")) 
        {
            firePW();
        }
        if (Greenfoot.isKeyDown("x")) 
        {
            shield();
        }
        if (Greenfoot.isKeyDown("left")) 
        {
            turn(-5);
        }
        if (Greenfoot.isKeyDown("right")) 
        {
            turn(5);
        }
        if (Greenfoot.isKeyDown("up")) {
            setImage(rocketWithThrust);
            addToVelocity(new Vector(getRotation(), 0.1));
        }else {
            setImage(rocket);
        }
    }
    
    /**
     * Fire a bullet if the gun is ready.
     */
    private void fire() 
    {
        if (reloadDelayCount >= gunReloadTime) 
        {
            Bullet bullet = new Bullet (getVelocity(), getRotation());
            getWorld().addObject (bullet, getX(), getY());
            bullet.move ();
            reloadDelayCount = 0;
        }
    }
    
    /**
     * Drop a Proton Wave into the game if it is ready.
     */
    private void firePW() 
    {
        if (pwReloadDelayCount >= pwReloadTime) 
        {
            ProtonWave pw = new ProtonWave();
            getWorld().addObject (pw, getX(), getY());
            pwReloadDelayCount = 0;
        }
    }
    
    /**
     * Release a Shield into the game if it is ready.
     */
    private void shield() 
    {
        if (sReloadDelayCount >= sReloadTime) 
        {
            Shield s = new Shield();
            getWorld().addObject (s, getX(), getY());
            sReloadDelayCount = 0;
        }
    }
    
    /**
     * Check if the Shield and Proton Wave are ready to be released and 
     * display that on the screen.
     */
    private void readyDisplay() {
        if (sReloadDelayCount >= sReloadTime) 
        {
            getWorld().showText("Shield: ready", 90, 45);
        } else {
            getWorld().showText("Shield: not ready", 90, 45);
        }
        if (pwReloadDelayCount >= pwReloadTime) 
        {
            getWorld().showText("Proton Wave: ready", 125, 20);
        } else {
            getWorld().showText("Proton Wave: not ready", 125, 20);
        }
    }
    
}
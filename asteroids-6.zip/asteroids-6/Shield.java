import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;

/**
 * The shield can be dropped and used to protect the rocket from having damage 
 * done to it by 
 * 
 * @author Blythe 
 * @version March 4, 2019
 */
public class Shield extends SmoothMover
{
    private int myTime = 0;             //How long the shield has been used since it was released.
    private int timeLimit = 300;         //How long the shield can be used before disappearing.
    
    /**
     * Create a new proton wave.
     */
    public Shield() {
        getImage().setTransparency(70);
    }
    
    /**
     * Let the sheild follow the rocket, c
     */
    public void act() 
    {
        if (myTime < timeLimit) {
            walk();
        } else {
            getWorld().removeObject(this);
        }
        myTime++;
     }
    
    /**
     * Move the shield so it stays with the rocket's movement.
     */
    public void walk() {
        List<Rocket> rocket = getWorld().getObjects(Rocket.class); 
        if (!rocket.isEmpty()) {
            Actor rockets = (Actor)rocket.get(0);
            int x = rockets.getX();
            int y = rockets.getY();
            setLocation(x,y);
        }
    }
}

import greenfoot.*;
import java.util.List;

/**
 * Space. Something for rockets to fly in.
 * 
 * @author Michael Kölling
 * @version 1.0
 */
public class Space extends World
{
    private Counter scoreCounter;
    private int startAsteroids = 2;
    private int score = 0;
    private int level = 1;
    
    /**
     * Create the space and all objects within it.
     */
    public Space() 
    {
        super(600, 500, 1);
        GreenfootImage background = getBackground();
        background.setColor(Color.BLACK);
        background.fill();
        
        Rocket rocket = new Rocket();
        addObject(rocket, getWidth()/2 + 100, getHeight()/2);
        
        addAsteroids(startAsteroids);
        
        scoreCounter = new Counter("Score: ");
        addObject(scoreCounter, 60, 480);

        ProtonWave.initializeImages();
        
        showText("Shield: ready", 90, 45);
        showText("Proton Wave: ready", 125, 20);
        
        drawStars(100);
        
        scoreCounter(0);
        
        levelUp();
    }
    
    /**
     * Call this method every act cycle and check if a level up is needed.
     */
    public void act() {
        levelUp();
    }
    
    /**
     * Add a given number of asteroids to our world. Asteroids are only added into
     * the left half of the world.
     */
    private void addAsteroids(int count) 
    {
        for(int i = 0; i < count; i++) 
        {
            int x = Greenfoot.getRandomNumber(getWidth()/2);
            int y = Greenfoot.getRandomNumber(getHeight()/2);
            addObject(new Asteroid(), x, y);
        }
    }
    
    /**
     * Draw stars in the background.
     */
    private void drawStars(int numStars)
    {
        GreenfootImage background = getBackground();
        background.setColor(Color.WHITE);
        for (int i = 0; i < numStars; i ++)
        {
            background.fillOval(Greenfoot.getRandomNumber(600), Greenfoot.getRandomNumber(500),Greenfoot.getRandomNumber(4)+1,Greenfoot.getRandomNumber(4)+1);
        }
    }
    
    /**
     * Keep track of score.
     */
    public void scoreCounter(int score) {
        this.score += score;
        scoreCounter.add(score);
    }
    
    /**
     * This method is called when the game is over to display the final score.
     */
    public void gameOver() {
        addObject(new ScoreBoard(score), getWidth()/2, getHeight()/2);
        Greenfoot.stop();
    }
    
    /**
     * If all the asteroids are gone, level up and create more asteroids.
     */
    public void levelUp() {
        int asteroidCount = getObjects(Asteroid.class).size();
        if (asteroidCount == 0)
        {
            Greenfoot.playSound("levelUp.wav");
            level++;
            addAsteroids(level + 1);
        }
        showText("Level: " + level, getWidth()-50, getHeight() - 20);
    }
}
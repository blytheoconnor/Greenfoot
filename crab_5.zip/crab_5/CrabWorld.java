import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class CrabWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class CrabWorld extends World
{
    public CrabWorld()
    {    
        super(560, 560, 1);
        populateWorld();
    }
    private void populateWorld() {
        for(int i = 0; i < 15; i++) {
          int x = Greenfoot.getRandomNumber(getWidth());
          int y = Greenfoot.getRandomNumber(getHeight());
          Worm worm = new Worm();
          addObject(worm, x, y);
        }
        for(int i = 0; i < 7; i++) {
          int x = Greenfoot.getRandomNumber(getWidth());
          int y = Greenfoot.getRandomNumber(getHeight());
          Crab crab = new Crab();
          addObject(crab, x, y);
        }
        Lobster lobster = new Lobster();
        addObject(lobster, 250, 250);
        Crab crab = new Crab();
        addObject(crab, 144, 488);
    }
}

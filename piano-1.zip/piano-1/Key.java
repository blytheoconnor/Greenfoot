import greenfoot.*;  // (World, Actor, GreenfootImage, and Greenfoot)

public class Key extends Actor
{
    private boolean isDown = false;
    private String key;
    private String note;
    
    public Key(String key, String note)
    {
        isDown = false;
        this.key = key;
        this.note = note;
    }

    /**
     * Do the action for this key.
     */
    public void act()
    {
        if (!isDown && Greenfoot.isKeyDown(this.key)) {
            setImage("white-key-down.png");
            Greenfoot.playSound(this.note);
            isDown = true;
        } 
        if (isDown && !Greenfoot.isKeyDown(this.key))
        {
            setImage("white-key.png");
            isDown = false;
        }
    }
}


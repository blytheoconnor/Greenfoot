import greenfoot.*;  // (World, Actor, GreenfootImage, and Greenfoot)

/**
 * A piano that can be played with the computer keyboard.
 * 
 * @author: M. Kölling
 * @version: 0.1
 */
public class Piano extends World
{
    private String[] whiteKeys  = { "a", "s", "d", "f", "g", "h", "j", "k", "l", ";", "'", "\\" };
    private String[] whiteNotes = { "3c.wav", "3d.wav", "3e.wav", "3f.wav", "3g.wav", "3a.wav", "3b.wav", "4c.wav", "4d.wav", "4e.wav", "4f.wav", "4g.wav" };
    private String[] blackKeys  = { "q", "w", "", "t", "u", "", "o", "p", "", "]"};
    private String[] blackNotes = { "3c#", "3d#", "", "3f#", "3g#", "3a#", "", "4c#", "4d#", "", "4f#"};
    public Piano() 
    {
        super(800, 340, 1);
        makeKeys();
    }
    private void makeKeys() {
        for (int i = 0; i < whiteKeys.length; i++) {
            addObject(new Key(whiteKeys[i], whiteNotes[i], "white"), i*63 + 53, 140);
        }
        for (int a = 0; a < blackKeys.length; a++) {
            if (blackKeys[a] != "") {
            addObject (new Key (blackKeys[a], blackNotes[a] + ".wav", "black"), 85 + (a*63), 86);
           }
        }
    }
}
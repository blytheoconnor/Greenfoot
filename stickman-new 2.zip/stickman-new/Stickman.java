import greenfoot.*;

/**
 * This is a stick man. Make him run and jump.
 * 
 * @author 
 * @version 
 */
public class Stickman extends Actor
{
    /**
     * Make the stickman act.
     */
    /**public void act() {
      * if (Greenfoot.getMicLevel() == 0){
            move(5);
        } else {
            moveLeftIfNoise();
        }
       checkGameOver();
    }    
    public void moveLeftIfNoise() {
        move(-5);
    }
    public void checkGameOver() {
        if (isAtEdge() == true) {
           gameOver();
        }
    }
    public void gameOver() {
        Greenfoot.playSound("gameover");
        
    }*/
    /**public void act() {
       floatNoise();
    } 
    public void floatNoise() 
    {   
      if ( Greenfoot.getMicLevel() > 1)
      {
          setLocation(getX(), getY() - Greenfoot.getMicLevel());
      } else {
          setLocation(getX(), getY() + 1);
        }
    } */
    public void act() 
    {   
      jump();
      checkGameOver();
    } 
    public void jump() 
    {   
      if ( Greenfoot.getMicLevel() > 1){
          setLocation(getX(), getY() - 5);
      } else {
          setLocation(getX(), getY() + 5);
      }
      if (getY() > 325) { 
          setLocation(getX(), 325);
      }
    } 
    public void checkGameOver () {
      if(isTouching(pig.class)){
        gameOver();
        }
    }
    public void gameOver() {
        Greenfoot.playSound("gameover.wav");
        Greenfoot.stop();
    }
}

import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class pig here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class pig extends Actor
{
    public void act() 
    {
        move(1);
        checkLocation();
    }  
    public void checkLocation() {
        if (isAtEdge() == true) {
            setLocation (1, 325);
        }
    }
}
